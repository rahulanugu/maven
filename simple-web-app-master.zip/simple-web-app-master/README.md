simple-web-app
==============

Simple web application that demonstrates the use of the OpenID Connect client code and configuration